﻿function change(ref) {
    ref.value = "Success!";
}