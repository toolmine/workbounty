﻿
try { ace.settings.check('sidebar', 'collapsed') } catch (e) { }