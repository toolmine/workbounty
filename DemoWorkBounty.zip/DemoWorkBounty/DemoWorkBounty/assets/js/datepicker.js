﻿$(document).ready(function () {

    $('#DateSelect').datepicker({
        format: "dd/mm/yyyy"
    });

});