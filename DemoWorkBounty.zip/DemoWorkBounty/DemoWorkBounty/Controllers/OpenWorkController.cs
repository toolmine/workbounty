﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoWorkBounty.Controllers
{
    public class OpenWorkController : Controller
    {
        public ActionResult Irctc()
        {
            return View();
        }

        public ActionResult makemytrip()
        {
            return View();
        }

    

        public ActionResult Epay()
        {
            return View();
        }

        public ActionResult message()
        {
            return View();
        }

        public ActionResult phpweb()
        {
            return View();
        }
        public ActionResult mongodb()
        {
            return View();
        }
        public ActionResult cloud()
        {
            return View();
        }
        public ActionResult crossplatform()
        {
            return View();
        }
        public ActionResult dotnet()
        {
            return View();
        }
        public ActionResult mysql()
        {
            return View();
        }
    }
}
