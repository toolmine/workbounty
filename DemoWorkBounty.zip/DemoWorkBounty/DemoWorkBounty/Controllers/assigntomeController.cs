﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoWorkBounty.Controllers
{
    public class assigntomeController : Controller
    {
        //
        // GET: /assigntome/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult airline()
        {
            return View();

        }
        public ActionResult javaplugin()
        {
            return View();

        }
        public ActionResult androidapplication()
        {
            return View();

        }
        public ActionResult websitedevelopment()
        {
            return View();

        }
        public ActionResult webapi()
        {
            return View();


        }
        public ActionResult c()
        {
            return View();

        }
        public ActionResult cplus()
        {
            return View();

        }
        public ActionResult androiddevelopment()
        {
            return View();

        }
        public ActionResult ecom()
        {
            return View();

        }
        public ActionResult system()
        {
            return View();

        }
   
    
    
    }
}
